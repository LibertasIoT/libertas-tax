Smith family sample papers, 2026

Synthetic test data. Never file these documents. Every page is marked
SYNTHETIC TEST DATA - NOT A TAX DOCUMENT. Names, addresses, EINs and accounts
are fictional.

Import one batch folder at a time in the tax App's Document center:
AI Import reads up to eight papers at once.
